<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataFollowUp extends Model
{
    protected $table = 'follow_up_data';

    protected $primaryKey = 'id';
}
