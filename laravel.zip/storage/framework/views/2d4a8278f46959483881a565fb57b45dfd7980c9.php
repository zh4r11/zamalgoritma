<?php $__env->startSection('title', 'User'); ?>

<?php $__env->startPush('page-styles'); ?>

 <!-- DataTables -->
 <link rel="stylesheet" href="<?php echo e(asset('bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">

 <?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        USER
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
    <div class="box">
        <div class="box-header with-border">
        <a href="#" class="btn btn-primary btn-lg">Send</a>
        </div>
    </div>
    <div class="box-body">
      <?php if(session('message')): ?>
        <div class="alert alert-success alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?php echo e(session('message')); ?>

        </div>
      <?php endif; ?>
        <table id="example1" class="table table-bordered table-striped table-sm">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Address</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $raw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r => $raw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($r+1); ?></td>
                    <td><?php echo e($raw->name); ?></td>
                    <td><?php echo e($raw->phone); ?></td>
                    <td><?php echo e($raw->address); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>No.</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Address</th>
                </tr>
            </tfoot>
        </table>
    </div>
        <!-- /.box-body -->

      <!-- /.box -->
      
      <div class="modal modal-danger fade" id="modal-delete">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                      <h4 class="modal-title">Delete User</h4>
                    </div>
                    <div class="modal-body">
                      <p>Are you sure to delete this data?</p>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">No</button>
                      <button type="button" class="btn btn-outline">Yes</button>
                    </div>
                  </div>
                  <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>
    </section>
    <!-- /.content -->
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>

<!-- Sweet Alert -->
<script src="<?php echo e(asset('node_modules/sweetalert/dist/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/page/modules-sweetalert.js')); ?>"></script>


<!-- DataTables -->
<script src="<?php echo e(asset('bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('after-scripts'); ?>
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })

  $(".swal-confirm").click(function(e) {
  id = e.target.dataset.id;
  swal({
      title: 'Are you sure?',
      text: 'Once deleted, you will not be able to recover this imaginary file!',
      icon: 'warning',
      buttons: true,
      dangerMode: true,
    })
    .then((willDelete) => {
        if (willDelete) {
        
        $(`#delete${id}`).submit();
      } else {
      }
    });
});

// $('.btn-del').on('click',function(){
//   console.log($(this).data('id'))
//   let id = $(this).data('id')
//   $.ajax({
//       url:'/user/delete/${id}',
//       method:"DELETE",
//       success: function(data){
//         console.log(data)
//         $('#modal-delete').modal('show')
//       },
//       error:function(error){
//         console.log(error)
//       }
//   })
// })

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Azhari\ZI\resources\views/rawdata.blade.php ENDPATH**/ ?>